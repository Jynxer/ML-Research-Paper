# CS4099 Senior Honours Project

Advanced forecasting of stock prices with long short-term memory neural network based on an attention mechanism.